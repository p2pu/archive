<?php
/*
Usuario p2pu.org: uniqdom

Utilicé la pagina http://www.opensourcecms.com/demo/1/38/Joomla como template.
agregue el código pedido, y modifiqué algunas partes para que se viera acorde a la tarea.

joomla es un CMS liberado bajo la licencia GPL

*/
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" dir="ltr" >
        <head>
                  <base href="http://demo.opensourcecms.com/joomla/" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="" />
  <meta name="rights" content="" />
  <meta name="language" content="en-GB" />

  <meta name="generator" content="Joomla! 1.6 - Open Source Content Management" />
  <title>Home</title>
  <link href="/joomla/index.php?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
  <link href="/joomla/index.php?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
  <link href="/joomla/templates/beez_20/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  <script type="text/javascript" src="/joomla/media/system/js/core.js"></script>
  <script type="text/javascript" src="/joomla/media/system/js/mootools-core.js"></script>

  <script type="text/javascript" src="/joomla/media/system/js/caption.js"></script>
  <script type="text/javascript" src="/joomla/media/system/js/mootools-more.js"></script>
  <script type="text/javascript">
function keepAlive() {	var myAjax = new Request({method: "get", url: "index.php"}).send();} window.addEvent("domready", function(){ keepAlive.periodical(840000); });
  </script>

                <link rel="stylesheet" href="/joomla/templates/system/css/system.css" type="text/css" />
                <link rel="stylesheet" href="/joomla/templates/beez_20/css/position.css" type="text/css" media="screen,projection" />
                <link rel="stylesheet" href="/joomla/templates/beez_20/css/layout.css" type="text/css" media="screen,projection" />

                <link rel="stylesheet" href="/joomla/templates/beez_20/css/print.css" type="text/css" media="Print" />

                <link rel="stylesheet" href="/joomla/templates/beez_20/css/general.css" type="text/css" />
                <link rel="stylesheet" href="/joomla/templates/beez_20/css/general_mozilla.css" type="text/css" />
                <link rel="stylesheet" href="/joomla/templates/beez_20/css/personal.css" type="text/css" />
                                <!--[if lte IE 6]>
                <link href="/joomla/templates/beez_20/css/ieonly.css" rel="stylesheet" type="text/css" />

                                <style type="text/css">
                #line
                {      width:98% ;
                }
                .logoheader
                {
                        height:200px;

                }
                #header ul.menu
                {
                display:block !important;
                      width:98.2% ;


                }
                 </style>
                                <![endif]-->
                <!--[if IE 7]>
                        <link href="/joomla/templates/beez_20/css/ie7only.css" rel="stylesheet" type="text/css" />
                <![endif]-->
                <script type="text/javascript" src="/joomla/templates/beez_20/javascript/md_stylechanger.js"></script>
                <script type="text/javascript" src="/joomla/templates/beez_20/javascript/hide.js"></script>

                <script type="text/javascript">
                        var big ='72%';
                        var small='53%';
                        var altopen='is open';
                        var altclose='is closed';
                        var bildauf='/joomla/templates/beez_20/images/plus.png';
                        var bildzu='/joomla/templates/beez_20/images/minus.png';
                        var rightopen='Open info';
                        var rightclose='Close info';
                        var fontSizeTitle='Font size';
                        var bigger='Bigger';
                        var reset='Reset';
                        var smaller='Smaller';
                        var biggerTitle='Increase size';
                        var resetTitle='Revert styles to default';
                        var smallerTitle='Decrease size';
                </script>

        </head>

        <body>

<div id="all">
        <div id="back">
                <div id="header">
                                <div class="logoheader">

                                        <h1 id="logo">

                                                                                <img src="/joomla/images/joomla_black.gif"  alt="Joomla!" />
                                                                                                                        <span class="header1">
                                        Open Source Content Management                                        </span></h1>
                                </div><!-- end logoheader -->
                                        <ul class="skiplinks">
                                                <li><a href="#main" class="u2">Skip to content</a></li>

                                                <li><a href="#nav" class="u2">Jump to main navigation and login</a></li>
                                                                                    </ul>
                                        <h2 class="unseen">Nav view search</h2>
                                        <h3 class="unseen">Navigation</h3>
                                        
<ul class="menu">
<li id="item-464"><a href="/joomla/" >Home</a></li><li id="item-444"><a href="/joomla/index.php/sample-sites" >Sample Sites</a></li><li id="item-207"><a href="http://joomla.org" >Joomla.org</a></li></ul>

                                        <div id="line">
                                        <div id="fontsize"></div>
                                        <h3 class="unseen">Search</h3>
                                        <form action="/joomla/index.php" method="post">
	<div class="search">
		<label for="mod-search-searchword">Search...</label><input name="searchword" id="mod-search-searchword" maxlength="20"  class="inputbox" type="text" size="20" value="Search..."  onblur="if (this.value=='') this.value='Search...';" onfocus="if (this.value=='Search...') this.value='';" />	<input type="hidden" name="task" value="search" />
	<input type="hidden" name="option" value="com_search" />

	<input type="hidden" name="Itemid" value="435" />
	</div>
</form>

                                        </div> <!-- end line -->


                        </div><!-- end header -->
                        <div id="contentarea">
                                        <div id="breadcrumbs">

                                            
                                                        
<div class="breadcrumbs">

</div>

                                            
                                        </div>

                                        

                                                        <div class="left1 leftbigger" id="nav">
                                                   <div class="moduletable_menu">
<?php

if (date('G')< 12) {
$mensaje = 'Buenos días. ';
} elseif (date('G') < 21){
$mensaje = 'Buenas tardes. ';
}else {
$mensaje = 'Buenas noches. ';
}

echo $mensaje. "Ingrese a su cuenta o registrese.";
?></div>
<div class="moduletable">
 <h3><span
	class="backh"><span class="backh2"><span class="backh3">Login Form</span></span></span></h3>
 <form action="/joomla/index.php" method="post" id="login-form" >
	<div class="pretext">
		</div>
	<fieldset class="userdata">
	<p id="form-login-username">
		<label for="modlgn-username">User Name</label>

		<input id="modlgn-username" type="text" name="username" class="inputbox"  size="18" />
	</p>
	<p id="form-login-password">
		<label for="modlgn-passwd">Password</label>
		<input id="modlgn-passwd" type="password" name="password" class="inputbox" size="18"  />
	</p>
		<p id="form-login-remember">
		<label for="modlgn-remember">Remember Me</label>

		<input id="modlgn-remember" type="checkbox" name="remember" class="inputbox" value="yes"/>
	</p>
		<input type="submit" name="Submit" class="button" value="Log in" />
	<input type="hidden" name="option" value="com_users" />
	<input type="hidden" name="task" value="user.login" />
	<input type="hidden" name="return" value="aW5kZXgucGhwP0l0ZW1pZD00MzU=" />
	<input type="hidden" name="0932bb764b9a60c5a9387bcffe2cd9e4" value="1" />	</fieldset>
	<ul>

		<li>
			<a href="/joomla/index.php/using-joomla/extensions/components/users-component/password-reset">
			Forgot your password?</a>
		</li>
		<li>
			<a href="/joomla/index.php/using-joomla/extensions/components/users-component/username-reminder">
			Forgot your username?</a>

		</li>

				<li>
			<a href="/joomla/index.php/using-joomla/extensions/components/users-component/registration-form">
				Create an account</a>
		</li>
			</ul>
	<div class="posttext">
		</div>

</form>
</div>
<div class="moduletable">
 <h3><span
	class="backh"><span class="backh2"><span class="backh3">About Joomla!</span></span></span></h3>

 

<ul class="menu">
<li id="item-437"><a href="/joomla/index.php/getting-started" >Getting Started</a></li><li id="item-280"><a href="/joomla/index.php/using-joomla" >Using Joomla!</a></li><li id="item-278"><a href="/joomla/index.php/the-joomla-project" >The Joomla! Project</a></li><li id="item-279"><a href="/joomla/index.php/the-joomla-community" >The Joomla! Community</a></li></ul></div>
<div class="moduletable_menu">
 <h3><span
	class="backh"><span class="backh2"><span class="backh3">This Site</span></span></span></h3>
 
<ul class="menu">
<li id="item-435" class="current active"><a href="/joomla/" >Home</a></li><li id="item-294"><a href="/joomla/index.php/site-map" >Site Map</a></li><li id="item-233"><a href="/joomla/index.php/login" >Login</a></li><li id="item-238"><a href="/joomla/index.php/sample-sites" >Sample Sites</a></li><li id="item-448"><a href="/joomla/administrator" target="_blank" >Site Administrator</a></li><li id="item-455"><a href="/joomla/index.php/using-joomla/extensions/components" >Example Pages</a></li></ul></div>



                                                                
                                                                


                                                        </div><!-- end navi -->
               
                                        <div id="wrapper2" >

                                                <div id="main">

                                                
                                                
                                                        
<div class="blog-featured">

<div class="items-leading">
			<div class="leading-0">

			
	

<?php
echo file_get_contents("gpl_wikipedia.txt");
?>




<div class="item-separator"></div>
		</div>
			</div>
	
	
			<div class="items-row cols-3 row-0">
				<div class="item column-1">
			
	<h2>

					<a href="/joomla/index.php/using-joomla/extensions/components/content-component/article-category-list/8-beginners">
			Beginners</a>

			</h2>


<?
echo "Numeros impares hasta el 300: ";
for ($a = 1; $a < 300; $a++)
        {
        if ($a%2==1){
                echo $a .' ';
                }
        }
?>


	


			<p class="readmore">
				<a href="/joomla/index.php/using-joomla/extensions/components/content-component/article-category-list/8-beginners">

					Read more: Beginners</a>
		</p>


<div class="item-separator"></div>
		</div>
						
			<div class="item column-2">

			
	<h2>
					<a href="/joomla/index.php/using-joomla/extensions/components/content-component/article-category-list/50-upgraders">
			Upgraders</a>

			</h2>





	

<p>If you are an experienced Joomla! 1.5 user, 1.6 will seem very familiar. There are new templates and improved user interfaces, but most functionality is the same. The biggest changes are improved access control (ACL) and nested categories.</p>

			<p class="readmore">
				<a href="/joomla/index.php/using-joomla/extensions/components/content-component/article-category-list/50-upgraders">
					Read more: Upgraders</a>

		</p>


<div class="item-separator"></div>
		</div>
						
			<div class="item column-3">

			
	<h2>
					<a href="/joomla/index.php/using-joomla/extensions/components/content-component/article-category-list/35-professionals">
			Professionals</a>
			</h2>





	

<p>Joomla! 1.6 continues development of the Joomla Framework and CMS as a powerful and flexible way to bring your vision of the web to reality. With the administrator now fully MVC, the ability to control its look and the management of extensions is now complete.</p>

			<p class="readmore">
				<a href="/joomla/index.php/using-joomla/extensions/components/content-component/article-category-list/35-professionals">
					Read more: Professionals</a>
		</p>


<div class="item-separator"></div>
		</div>
									<span class="row-separator"></span>

				</div>

				


</div>



                                                </div><!-- end main -->

                                        </div><!-- end wrapper -->

                                
                        
                                <div class="wrap"></div>

                                </div> <!-- end contentarea -->

                        </div><!-- back -->

                </div><!-- all -->

                <div id="footer-outer">
                        
                        <div id="footer-sub">


                                <div id="footer">

                                        <p>
<?php

$fecha= date ("j/n/Y");
$hora= date ("H:i:s");

echo "Esta pagina fue generada el día " . $fecha . " a las " . $hora;
?>

                                        <p>
                                                Powered by <a href="http://www.joomla.org/">Joomla!&#174;</a>
                                        </p>


                                </div><!-- end footer -->

                        </div>

                </div>

        </body>
</html>


